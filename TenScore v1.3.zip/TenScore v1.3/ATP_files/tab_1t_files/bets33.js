var al = new Array();
//--
function line(nom,val) {
	this.nom=nom;
	this.val=val;
}
//--
function getd(n) {
url="actions/mgetd.mpl?used="+escape(n);
w=makeWnd("lws");
with (w) {
	focus();
	document.open();
	document.write("<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1251'></head>");
	if (document.all) {
		document.write("<body bgcolor=#c8dcdc><p align=center><big>���������, ����������...</big></p></body></html>");
	} else {
		document.write("<body bgcolor=#FFFFFF><p align=center><big>Wait...</big></p></body></html>");
	}
	document.close();
	location.href=url;
} 
}
//--
function makeWnd(wname) {
posStr='';
sw=screen.width;
sh=screen.height;
ww=sw-220;
//wh=sh-Math.round(sh/100*25);
wh=sh-175;
posx=(sw-ww)-15;
posy=0;
if(document.all) posStr=',left='+posx+',top='+posy;
else if(document.layers) posStr=',screenX='+posx+',screenY='+posy;

w = open("",wname,"location=0,menubar=1,toolbar=1,status=1,scrollbars=1,resizable=1,height="+wh+",width="+ww+posStr);
w.focus();                    
return (w);
}
//--
function LoadPage(url,wname) {
w=makeWnd(wname);
w.location=url;
}
//--
function addLine(r,value,col) {
for (var k=0; k<al.length && al[k]!=null; k++) ;
al[k] = new line(r.name.substring(1),value);

with (document.f1) {
	nom='i'+r.name.substring(1);
	if (document.all && typeof(eval('document.all.'+nom)) == 'object') {
		sg=eval('document.all.'+nom+'.style');
		sg.backgroundColor="#000099";  //col; //"#dce2d6";
	} 
	//����� �������
	nom='r'+r.name.substring(1);
	if (typeof(eval('document.f1.'+nom))=='object') {
			if (typeof(eval(nom+'.length'))=='undefined') elements[nom].checked=false;
			else for (i=0; i<eval(nom+'.length'); i++) with(elements[nom][i])
				if(checked) {checked=false;break;};
	}
}
}
//--
function doSend() {
w=makeWnd("lws");
with (w) {
	focus();
    document.open();
	document.write("<html><head><meta http-equiv='Content-Type' content='text/html; charset=windows-1251'></head>");
	if (document.all) {
		document.write("<body bgcolor=#FFFFFF><p align=center><big>���������, ����������...</big></p></body></html>");
	} else {
		document.write("<body bgcolor=#FFFFFF><p align=center><big>Wait...</big></p></body></html>");
	}
	document.close();
}
with (document.f1 ) {
dp.value='';
for (var i=al.length; i>=0; i--) if (al[i]!=null) dp.value+=al[i].val+'|';
target='lws';
action='members/actions/mcheck.mpl';
submit();
}
}
//--
function cl() {
var dt='',pos1=0,pos2=0,delim='|';
for (var i=0; i<al.length;i++) {
	if (document.all && (al[i]!=null) && (typeof(eval('document.all.i'+al[i].nom)) == 'object')) {
		sg=eval('document.all.i'+al[i].nom+'.style');
		sg.backgroundColor=document.body.bgColor;
	}
	al[i]=null;
}	
document.f1.dp.value='';	
document.f1.reset();
}

